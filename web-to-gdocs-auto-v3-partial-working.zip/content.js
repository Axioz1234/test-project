// This script runs on every webpage and monitors for copy events
console.log("📋 Content script loaded on " + window.location.href);

// Initialize floating button and auto-copy functionality
let lastCopiedText = '';
let lastCopyTime = 0;
let floatingButton = null;

// Create floating button when the page loads
window.addEventListener('load', createFloatingButton);

// Check if we should show the floating button
chrome.storage.local.get('showFloatingButton', function(result) {
  // Default to true if not set
  const showButton = result.showFloatingButton !== false;
  if (showButton) {
    createFloatingButton();
  }
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'toggleFloatingButton') {
    if (request.show) {
      createFloatingButton();
    } else if (floatingButton) {
      // Remove the button if it exists
      floatingButton.remove();
      floatingButton = null;
    }
    sendResponse({success: true});
  }
  return true;
});

// Method 1: Standard copy event listener
document.addEventListener('copy', function(event) {
  console.log("📋 Copy event detected");
  handleCopyEvent();
});

// Method 2: Selection change monitoring
document.addEventListener('selectionchange', function() {
  // This helps detect copy events that might not trigger the copy event
  if (document.hasFocus()) {
    // Listen for Ctrl+C or Command+C
    document.addEventListener('keydown', function(e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        console.log("📋 Keyboard copy detected (Ctrl/Cmd+C)");
        setTimeout(handleCopyEvent, 100); // Small delay to let the copy happen
      }
    }, { once: true });
  }
});

// Method 3: Clipboard API (where supported)
if (navigator.clipboard && navigator.clipboard.readText) {
  // Poll clipboard periodically (only in active tabs)
  let isActive = true;
  
  window.addEventListener('focus', () => { isActive = true; });
  window.addEventListener('blur', () => { isActive = false; });
  
  // Check clipboard every 2 seconds when tab is active
  setInterval(() => {
    if (isActive) {
      try {
        navigator.clipboard.readText().then(text => {
          if (text && text.trim() && text !== lastCopiedText) {
            console.log("📋 New clipboard content detected");
            lastCopiedText = text;
            sendTextToBackgroundScript(text);
          }
        }).catch(err => {
          // Silent fail - clipboard permission may not be granted
        });
      } catch (e) {
        // Silent fail for unsupported browsers
      }
    }
  }, 2000);
}

// Handle copy events
function handleCopyEvent() {
  // Prevent duplicate processing
  const now = Date.now();
  if (now - lastCopyTime < 1000) {
    return; // Ignore if less than 1 second since last copy
  }
  lastCopyTime = now;
  
  try {
    // Get selected text
    const selectedText = window.getSelection().toString().trim();
    
    if (selectedText && selectedText !== lastCopiedText) {
      console.log("📋 Text copied: " + selectedText.substring(0, 50) + (selectedText.length > 50 ? "..." : ""));
      lastCopiedText = selectedText;
      sendTextToBackgroundScript(selectedText);
    }
  } catch (e) {
    console.error("📋 Error in copy handler:", e);
  }
}

// Send text to background script
function sendTextToBackgroundScript(text) {
  chrome.runtime.sendMessage({
    action: 'textCopied',
    text: text,
    url: window.location.href,
    title: document.title
  }, function(response) {
    if (response && response.success) {
      console.log("📋 Successfully sent to Google Doc");
      showNotification("Text copied to Google Doc!", false);
    } else if (response && response.error) {
      console.error("📋 Error sending to Google Doc:", response.error);
      showNotification("Error: " + response.error, true);
    } else {
      console.log("📋 No response from background script");
    }
  });
}

// Create floating button for manual copying
function createFloatingButton() {
  // If button already exists, don't create another one
  if (floatingButton || document.getElementById('gdocs-copy-button')) {
    return;
  }
  
  try {
    // Create the button
    floatingButton = document.createElement('div');
    floatingButton.id = 'gdocs-copy-button';
    floatingButton.innerHTML = '📋';
    floatingButton.title = 'Copy selected text to Google Doc';
    
    // Style the button
    floatingButton.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 50px;
      height: 50px;
      border-radius: 25px;
      background-color: #4285F4;
      color: white;
      font-size: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
      z-index: 9999;
      transition: transform 0.2s, background-color 0.2s;
    `;
    
    // Add hover effect
    floatingButton.addEventListener('mouseover', function() {
      this.style.transform = 'scale(1.1)';
      this.style.backgroundColor = '#3367D6';
    });
    
    floatingButton.addEventListener('mouseout', function() {
      this.style.transform = 'scale(1)';
      this.style.backgroundColor = '#4285F4';
    });
    
    // Add click handler
    floatingButton.addEventListener('click', function() {
      // Get selected text
      const selectedText = window.getSelection().toString().trim();
      
      if (selectedText) {
        // Show immediate feedback
        this.innerHTML = '✓';
        setTimeout(() => { this.innerHTML = '📋'; }, 1000);
        
        // Send to Google Doc
        sendTextToBackgroundScript(selectedText);
      } else {
        // Indicate no text selected
        this.innerHTML = '❓';
        setTimeout(() => { this.innerHTML = '📋'; }, 1000);
        showNotification('No text selected. Select text first.', true);
      }
    });
    
    // Add the button to the page
    document.body.appendChild(floatingButton);
    console.log("📋 Floating button added to page");
    
  } catch (e) {
    console.error("📋 Error creating floating button:", e);
  }
}

// Show a brief notification
function showNotification(message, isError) {
  // Create notification element
  const notification = document.createElement('div');
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    background-color: ${isError ? '#F44336' : '#4CAF50'};
    color: white;
    border-radius: 4px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    z-index: 9999;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    transition: opacity 0.3s;
  `;
  
  // Add to page
  document.body.appendChild(notification);
  
  // Remove after delay
  setTimeout(function() {
    notification.style.opacity = '0';
    setTimeout(function() {
      if (notification.parentNode) {
        document.body.removeChild(notification);
      }
    }, 300);
  }, 3000);
}